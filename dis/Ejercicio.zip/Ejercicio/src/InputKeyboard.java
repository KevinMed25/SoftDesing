public class InputKeyboard {

    public char readChar() {
        return 'A';
    }
}
