public class OutputConsole {

    public void writeChar(char c) {
        System.out.println(c);
    }
}
